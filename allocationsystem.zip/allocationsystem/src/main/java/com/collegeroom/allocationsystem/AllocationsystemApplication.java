package com.collegeroom.allocationsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AllocationsystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(AllocationsystemApplication.class, args);
	}

}
